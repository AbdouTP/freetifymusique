# Freetify Musique — starter iOS

Application iPhone SwiftUI, avec une interface sombre inspirée des lecteurs musicaux modernes et une identité violet/vert.

## Fonctions incluses dans cette première version
- Import de fichiers audio depuis l'app Fichiers / iCloud Drive via le sélecteur iOS.
- Copie des morceaux dans le stockage privé de l'application (`Documents/FreetifyMusic`).
- Bibliothèque locale persistante (index JSON), recherche et favoris.
- Lecture locale via AVPlayer, commandes précédent/suivant et mini-lecteur.
- Configuration audio pour lecture en arrière-plan et commandes écran verrouillé / Centre de contrôle.
- Aucun compte, serveur, streaming ni connexion réseau nécessaire pour lire les morceaux importés.

## Ouvrir dans Xcode
1. Sur un Mac, ouvre Xcode et crée un nouveau projet **iOS > App** nommé `FreetifyMusique`.
2. Choisis **SwiftUI** et **Swift**.
3. Supprime le `ContentView.swift` et le fichier `FreetifyMusiqueApp.swift` générés par Xcode.
4. Glisse tous les fichiers `.swift` de ce dossier dans le groupe du projet, en cochant **Copy items if needed** et la cible de l'app.
5. Dans **Signing & Capabilities**, sélectionne ton équipe Apple. Pour la lecture écran verrouillé, ajoute la capacité **Background Modes** puis coche **Audio, AirPlay, and Picture in Picture**.
6. Dans **Deployment Info**, choisis iOS 16.0 ou plus récent, puis lance sur ton iPhone.

## Importer de la musique
Dans Freetify, touche le bouton `+` et sélectionne un ou plusieurs fichiers audio dans l'app Fichiers. L'application en fait une copie locale : les fichiers importés restent disponibles sans Wi-Fi ni données mobiles.

## Limites / prochaines étapes
- Le logo graphique final fourni dans la conversation n'est pas encore intégré comme asset ; l'interface utilise pour l'instant une icône waveform temporaire.
- La lecture dépend des formats pris en charge par AVPlayer/iOS (MP3, AAC/M4A, WAV et autres formats compatibles selon l'appareil/iOS).
- Les morceaux provenant d'un service avec DRM ne peuvent pas être importés/écoutés comme de simples fichiers audio.
- Cette archive contient le code source ; la compilation, la signature et l'installation sur iPhone nécessitent Xcode sur macOS et une signature Apple valide.

Le logo Freetify généré pour ce projet est inclus dans `Assets.xcassets/FreetifyLogo.imageset` ; ajoute également ce dossier d'assets à la cible du projet Xcode.
