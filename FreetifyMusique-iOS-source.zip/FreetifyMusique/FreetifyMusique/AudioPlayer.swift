import Foundation
import Combine
import AVFoundation
import MediaPlayer

@MainActor
final class AudioPlayer: ObservableObject {
    @Published private(set) var currentTrack: Track?
    @Published private(set) var isPlaying = false
    @Published private(set) var progress: Double = 0
    @Published private(set) var duration: Double = 0

    private var player: AVPlayer?
    private var timeObserver: Any?
    private var queue: [Track] = []

    init() {
        configureAudioSession()
        configureRemoteCommands()
    }

    func play(_ track: Track, from tracks: [Track]) {
        queue = tracks
        currentTrack = track
        let item = AVPlayerItem(url: track.fileURL)
        player?.pause()
        player = AVPlayer(playerItem: item)
        player?.play()
        isPlaying = true
        observeProgress()
        updateNowPlaying()
    }

    func togglePlayback() {
        guard let player else { return }
        if isPlaying { player.pause() } else { player.play() }
        isPlaying.toggle()
        updateNowPlaying()
    }

    func next() {
        guard let currentTrack, let index = queue.firstIndex(of: currentTrack), !queue.isEmpty else { return }
        play(queue[(index + 1) % queue.count], from: queue)
    }

    func previous() {
        guard let currentTrack, let index = queue.firstIndex(of: currentTrack), !queue.isEmpty else { return }
        play(queue[(index - 1 + queue.count) % queue.count], from: queue)
    }

    func seek(to value: Double) {
        guard duration > 0 else { return }
        player?.seek(to: CMTime(seconds: min(max(value, 0), duration), preferredTimescale: 600))
    }

    private func configureAudioSession() {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [])
            try AVAudioSession.sharedInstance().setActive(true)
        } catch { print("Freetify audio session: \(error)") }
    }

    private func observeProgress() {
        if let timeObserver { player?.removeTimeObserver(timeObserver) }
        timeObserver = player?.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.5, preferredTimescale: 600), queue: .main) { [weak self] time in
            Task { @MainActor in
                guard let self else { return }
                self.progress = time.seconds.isFinite ? time.seconds : 0
                let seconds = self.player?.currentItem?.duration.seconds ?? 0
                self.duration = seconds.isFinite ? seconds : 0
                if self.duration > 0 && self.progress >= self.duration - 0.4 { self.next() }
            }
        }
    }

    private func configureRemoteCommands() {
        let center = MPRemoteCommandCenter.shared()
        center.playCommand.addTarget { [weak self] _ in Task { @MainActor in self?.toggleIfNeeded(true) }; return .success }
        center.pauseCommand.addTarget { [weak self] _ in Task { @MainActor in self?.toggleIfNeeded(false) }; return .success }
        center.nextTrackCommand.addTarget { [weak self] _ in Task { @MainActor in self?.next() }; return .success }
        center.previousTrackCommand.addTarget { [weak self] _ in Task { @MainActor in self?.previous() }; return .success }
    }

    private func toggleIfNeeded(_ shouldPlay: Bool) {
        guard isPlaying != shouldPlay else { return }
        togglePlayback()
    }

    private func updateNowPlaying() {
        guard let currentTrack else { return }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = [
            MPMediaItemPropertyTitle: currentTrack.title,
            MPMediaItemPropertyArtist: currentTrack.artist,
            MPNowPlayingInfoPropertyElapsedPlaybackTime: progress,
            MPMediaItemPropertyPlaybackDuration: duration,
            MPNowPlayingInfoPropertyPlaybackRate: isPlaying ? 1.0 : 0.0
        ]
    }

    deinit {
        if let timeObserver { player?.removeTimeObserver(timeObserver) }
    }
}
