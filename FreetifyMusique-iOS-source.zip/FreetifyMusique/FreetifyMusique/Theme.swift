import SwiftUI

enum FreetifyTheme {
    static let background = Color(red: 0.055, green: 0.047, blue: 0.09)
    static let surface = Color(red: 0.105, green: 0.085, blue: 0.15)
    static let purple = Color(red: 0.58, green: 0.28, blue: 0.95)
    static let green = Color(red: 0.62, green: 0.96, blue: 0.30)
}
