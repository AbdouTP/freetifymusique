import Foundation

struct Track: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var filename: String
    var title: String
    var artist: String
    var isFavorite: Bool = false

    var fileURL: URL {
        MusicLibrary.musicFolder.appendingPathComponent(filename)
    }
}
