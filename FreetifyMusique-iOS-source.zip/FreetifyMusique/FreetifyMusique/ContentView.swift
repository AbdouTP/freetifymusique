import SwiftUI
import UniformTypeIdentifiers

private enum FreetifyTab: String, CaseIterable {
    case home = "Accueil", search = "Recherche", library = "Bibliothèque"
    var symbol: String {
        switch self { case .home: return "house.fill"; case .search: return "magnifyingglass"; case .library: return "books.vertical.fill" }
    }
}

struct ContentView: View {
    @EnvironmentObject private var library: MusicLibrary
    @EnvironmentObject private var player: AudioPlayer
    @State private var selectedTab: FreetifyTab = .home
    @State private var showingImporter = false
    @State private var showingPlayer = false
    @State private var searchText = ""

    private var visibleTracks: [Track] {
        let source = selectedTab == .library ? library.tracks.filter(\.isFavorite) : library.tracks
        guard selectedTab == .search, !searchText.isEmpty else { return source }
        return source.filter { $0.title.localizedCaseInsensitiveContains(searchText) || $0.artist.localizedCaseInsensitiveContains(searchText) }
    }

    var body: some View {
        ZStack {
            FreetifyTheme.background.ignoresSafeArea()
            VStack(spacing: 0) {
                header
                if selectedTab == .search { searchField }
                ScrollView {
                    VStack(alignment: .leading, spacing: 22) {
                        if selectedTab == .home { welcomeSection }
                        if selectedTab == .library {
                            Text("Tes favoris").font(.title2.bold()).foregroundStyle(.white)
                        } else if selectedTab == .search {
                            Text("Résultats").font(.title2.bold()).foregroundStyle(.white)
                        } else {
                            Text("Ta bibliothèque hors ligne").font(.title2.bold()).foregroundStyle(.white)
                        }
                        if visibleTracks.isEmpty { emptyState } else { trackList }
                    }
                    .padding(.horizontal, 20).padding(.top, 20).padding(.bottom, 120)
                }
                if player.currentTrack != nil { miniPlayer }
                tabBar
            }
        }
        .fileImporter(isPresented: $showingImporter, allowedContentTypes: [.audio], allowsMultipleSelection: true) { result in
            switch result {
            case .success(let urls): Task { await library.importFiles(urls) }
            case .failure(let error): library.importMessage = error.localizedDescription
            }
        }
        .sheet(isPresented: $showingPlayer) { NowPlayingView().environmentObject(library).environmentObject(player).presentationDetents([.medium, .large]) }
        .alert("Freetify Musique", isPresented: Binding(get: { library.importMessage != nil }, set: { if !$0 { library.importMessage = nil } })) {
            Button("OK", role: .cancel) { library.importMessage = nil }
        } message: { Text(library.importMessage ?? "") }
    }

    private var header: some View {
        HStack(spacing: 10) {
            Image("FreetifyLogo")
                .resizable().scaledToFill()
                .frame(width: 44, height: 44).clipShape(RoundedRectangle(cornerRadius: 12))
            VStack(alignment: .leading, spacing: 0) {
                Text("Freetify").font(.title2.bold()).foregroundStyle(.white)
                Text("MUSIQUE").font(.system(size: 9, weight: .heavy, design: .rounded)).tracking(2.5).foregroundStyle(FreetifyTheme.green)
            }
            Spacer()
            Button { showingImporter = true } label: {
                Image(systemName: "plus").font(.system(size: 17, weight: .bold)).foregroundStyle(.black).frame(width: 42, height: 42).background(FreetifyTheme.green, in: Circle())
            }.accessibilityLabel("Importer des musiques")
        }.padding(.horizontal, 20).padding(.top, 12).padding(.bottom, 10)
    }

    private var welcomeSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("TA MUSIQUE.\nSANS LIMITES.").font(.system(size: 30, weight: .black, design: .rounded)).foregroundStyle(.white)
            Text("Écoute tes morceaux même sans connexion.").font(.subheadline).foregroundStyle(.white.opacity(0.65))
            Button { showingImporter = true } label: {
                Label("Importer des musiques", systemImage: "arrow.down.to.line")
                    .font(.subheadline.bold()).foregroundStyle(.black).padding(.horizontal, 18).padding(.vertical, 13)
                    .background(FreetifyTheme.green, in: Capsule())
            }
        }.frame(maxWidth: .infinity, alignment: .leading).padding(20)
            .background(LinearGradient(colors: [Color(red: 0.27, green: 0.12, blue: 0.42), Color(red: 0.10, green: 0.24, blue: 0.18)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 24))
    }

    private var searchField: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass").foregroundStyle(FreetifyTheme.green)
            TextField("Titre ou artiste", text: $searchText).foregroundStyle(.white)
        }.padding(14).background(FreetifyTheme.surface, in: RoundedRectangle(cornerRadius: 14)).padding(.horizontal, 20)
    }

    private var trackList: some View {
        VStack(spacing: 4) {
            ForEach(visibleTracks) { track in
                HStack(spacing: 12) {
                    Button { player.play(track, from: visibleTracks) } label: {
                        HStack(spacing: 12) {
                            ZStack {
                                RoundedRectangle(cornerRadius: 10).fill(LinearGradient(colors: [FreetifyTheme.purple.opacity(0.8), FreetifyTheme.green.opacity(0.5)], startPoint: .topLeading, endPoint: .bottomTrailing))
                                Image(systemName: "music.note").font(.title3.bold()).foregroundStyle(.white)
                            }.frame(width: 48, height: 48)
                            VStack(alignment: .leading, spacing: 4) {
                                Text(track.title).font(.subheadline.weight(.semibold)).foregroundStyle(.white).lineLimit(1)
                                Text(track.artist).font(.caption).foregroundStyle(.white.opacity(0.55)).lineLimit(1)
                            }
                            Spacer(minLength: 0)
                        }
                    }.buttonStyle(.plain)
                    Button { library.toggleFavorite(track) } label: {
                        Image(systemName: track.isFavorite ? "heart.fill" : "heart").foregroundStyle(track.isFavorite ? FreetifyTheme.green : .white.opacity(0.45)).padding(8)
                    }
                    Menu {
                        Button(role: .destructive) { library.remove(track) } label: { Label("Supprimer de Freetify", systemImage: "trash") }
                    } label: { Image(systemName: "ellipsis").foregroundStyle(.white.opacity(0.55)).padding(8) }
                }.padding(.vertical, 7)
            }
        }
    }

    private var emptyState: some View {
        VStack(spacing: 12) {
            Image(systemName: selectedTab == .library ? "heart" : "music.note.list").font(.system(size: 38)).foregroundStyle(FreetifyTheme.green)
            Text(selectedTab == .library ? "Aucun favori pour le moment" : "Ta bibliothèque est vide").font(.headline).foregroundStyle(.white)
            Text("Ajoute des fichiers audio depuis ton iPhone pour les écouter hors connexion.").font(.caption).foregroundStyle(.white.opacity(0.55)).multilineTextAlignment(.center)
            Button("Importer des musiques") { showingImporter = true }.font(.subheadline.bold()).foregroundStyle(FreetifyTheme.green).padding(.top, 4)
        }.frame(maxWidth: .infinity).padding(.vertical, 36)
    }

    private var miniPlayer: some View {
        Button { showingPlayer = true } label: {
            HStack(spacing: 12) {
                Image(systemName: "waveform").foregroundStyle(FreetifyTheme.green).frame(width: 40, height: 40).background(FreetifyTheme.purple.opacity(0.45), in: RoundedRectangle(cornerRadius: 9))
                VStack(alignment: .leading, spacing: 3) {
                    Text(player.currentTrack?.title ?? "Aucune musique").font(.caption.bold()).foregroundStyle(.white).lineLimit(1)
                    Text(player.currentTrack?.artist ?? "").font(.caption2).foregroundStyle(.white.opacity(0.55)).lineLimit(1)
                }
                Spacer()
                Button { player.previous() } label: { Image(systemName: "backward.end.fill").foregroundStyle(.white).padding(5) }.buttonStyle(.plain)
                Button { player.togglePlayback() } label: { Image(systemName: player.isPlaying ? "pause.fill" : "play.fill").font(.title3).foregroundStyle(FreetifyTheme.green).padding(5) }.buttonStyle(.plain)
                Button { player.next() } label: { Image(systemName: "forward.end.fill").foregroundStyle(.white).padding(5) }.buttonStyle(.plain)
            }.padding(10).background(FreetifyTheme.surface, in: RoundedRectangle(cornerRadius: 15))
        }.buttonStyle(.plain).padding(.horizontal, 14).padding(.bottom, 8)
    }

    private var tabBar: some View {
        HStack {
            ForEach(FreetifyTab.allCases, id: \.self) { tab in
                Button { selectedTab = tab } label: {
                    VStack(spacing: 5) {
                        Image(systemName: tab.symbol).font(.system(size: 18, weight: .semibold))
                        Text(tab.rawValue).font(.system(size: 10, weight: .semibold))
                    }.foregroundStyle(selectedTab == tab ? FreetifyTheme.green : .white.opacity(0.45)).frame(maxWidth: .infinity).padding(.top, 10).padding(.bottom, 5)
                }
            }
        }.background(FreetifyTheme.surface)
    }
}

private struct NowPlayingView: View {
    @EnvironmentObject private var library: MusicLibrary
    @EnvironmentObject private var player: AudioPlayer
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ZStack {
            FreetifyTheme.background.ignoresSafeArea()
            VStack(spacing: 22) {
                HStack { Text("EN COURS DE LECTURE").font(.caption.bold()).tracking(2).foregroundStyle(FreetifyTheme.green); Spacer(); Button { dismiss() } label: { Image(systemName: "chevron.down").foregroundStyle(.white) } }
                Spacer(minLength: 0)
                ZStack {
                    RoundedRectangle(cornerRadius: 30).fill(LinearGradient(colors: [FreetifyTheme.purple, FreetifyTheme.green.opacity(0.75)], startPoint: .topLeading, endPoint: .bottomTrailing))
                    Image(systemName: "waveform").font(.system(size: 85, weight: .light)).foregroundStyle(.white)
                }.frame(width: 230, height: 230).shadow(color: FreetifyTheme.purple.opacity(0.35), radius: 25)
                VStack(spacing: 6) {
                    Text(player.currentTrack?.title ?? "Aucune musique").font(.title2.bold()).foregroundStyle(.white).lineLimit(1)
                    Text(player.currentTrack?.artist ?? "").foregroundStyle(.white.opacity(0.6))
                }
                VStack(spacing: 7) {
                    Slider(value: Binding(get: { player.progress }, set: { player.seek(to: $0) }), in: 0...max(player.duration, 1)).tint(FreetifyTheme.green)
                    HStack { Text(time(player.progress)); Spacer(); Text(time(player.duration)) }.font(.caption2.monospacedDigit()).foregroundStyle(.white.opacity(0.5))
                }
                HStack(spacing: 42) {
                    Button { player.previous() } label: { Image(systemName: "backward.end.fill").font(.title2) }
                    Button { player.togglePlayback() } label: { Image(systemName: player.isPlaying ? "pause.fill" : "play.fill").font(.system(size: 27, weight: .bold)).foregroundStyle(.black).frame(width: 68, height: 68).background(FreetifyTheme.green, in: Circle()) }
                    Button { player.next() } label: { Image(systemName: "forward.end.fill").font(.title2) }
                }.foregroundStyle(.white)
                Spacer(minLength: 0)
            }.padding(26)
        }
    }

    private func time(_ value: Double) -> String {
        guard value.isFinite else { return "0:00" }
        return String(format: "%d:%02d", Int(value) / 60, Int(value) % 60)
    }
}
