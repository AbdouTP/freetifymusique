import Foundation
import Combine
import AVFoundation
import UniformTypeIdentifiers

@MainActor
final class MusicLibrary: ObservableObject {
    @Published private(set) var tracks: [Track] = []
    @Published var importMessage: String?

    static let musicFolder: URL = {
        let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return documents.appendingPathComponent("FreetifyMusic", isDirectory: true)
    }()

    private var indexURL: URL { Self.musicFolder.appendingPathComponent("library.json") }

    init() {
        try? FileManager.default.createDirectory(at: Self.musicFolder, withIntermediateDirectories: true)
        loadLibrary()
    }

    func importFiles(_ urls: [URL]) async {
        var imported = 0
        for source in urls {
            let granted = source.startAccessingSecurityScopedResource()
            defer { if granted { source.stopAccessingSecurityScopedResource() } }
            let ext = source.pathExtension.isEmpty ? "audio" : source.pathExtension
            let destinationName = "\(UUID().uuidString).\(ext)"
            let destination = Self.musicFolder.appendingPathComponent(destinationName)
            do {
                try FileManager.default.copyItem(at: source, to: destination)
                let asset = AVURLAsset(url: destination)
                let metadata = (try? await asset.load(.commonMetadata)) ?? []
                let title = metadata.first(where: { $0.commonKey?.rawValue == "title" })?.stringValue
                let artist = metadata.first(where: { $0.commonKey?.rawValue == "artist" })?.stringValue
                let fallback = source.deletingPathExtension().lastPathComponent
                tracks.append(Track(filename: destinationName,
                                    title: title?.isEmpty == false ? title! : fallback,
                                    artist: artist?.isEmpty == false ? artist! : "Artiste inconnu"))
                imported += 1
            } catch {
                importMessage = "Impossible d'importer \(source.lastPathComponent) : \(error.localizedDescription)"
            }
        }
        saveLibrary()
        if imported > 0 { importMessage = "\(imported) musique(s) ajoutée(s) à Freetify." }
    }

    func toggleFavorite(_ track: Track) {
        guard let index = tracks.firstIndex(where: { $0.id == track.id }) else { return }
        tracks[index].isFavorite.toggle()
        saveLibrary()
    }

    func remove(_ track: Track) {
        try? FileManager.default.removeItem(at: track.fileURL)
        tracks.removeAll { $0.id == track.id }
        saveLibrary()
    }

    private func loadLibrary() {
        guard let data = try? Data(contentsOf: indexURL),
              let saved = try? JSONDecoder().decode([Track].self, from: data) else { return }
        tracks = saved.filter { FileManager.default.fileExists(atPath: $0.fileURL.path) }
    }

    private func saveLibrary() {
        guard let data = try? JSONEncoder().encode(tracks) else { return }
        try? data.write(to: indexURL, options: .atomic)
    }
}
